Welcome to the Groovy Gilded Rose
=================================

to run the test, you can either:
- run them from your favorite IDE
  - make sure you have installed language support for Groovy
  - IntelliJ:
	- open project
	- choose this folder (Groovy)
  - Eclipse:
    - new Groovy Project
	- choose this folder (Groovy) as the project folder
	- add JUnit to build path
- run the test from the src/ folder in your shell:
  - $ cd src/
  - $ groovy com/gildedrose/GildedRoseTest.groovy

