package main

import "testing"

func Test_GildedRose(t *testing.T) {
	main()
}
